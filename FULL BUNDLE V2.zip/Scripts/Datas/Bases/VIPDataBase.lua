
--[[
	由脚本生成，不要手动修改
	由脚本生成，不要手动修改
	由脚本生成，不要手动修改
--]]
local VIPDataBase = {
	
	setBubbleSwitch = nil,
	
	notify = nil,
	
	getPlayerVipInfo = nil,
	
	getVipDailyReward = nil,
	
}

-- Scripts.Data
VIPDataBase.data = nil

--table.setReadAndWriteVerify(VIPDataBase, true)
return VIPDataBase
