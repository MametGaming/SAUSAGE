var "WindowManager"
WindowManager =
    class(
    {
        windows = {},
        controllerManager = nil,
        onShowEvent = nil,
        onHideEvent = nil,
        onBeforeOpenEvent = nil,
        onBeforeCloseEvent = nil
    }
)

function WindowManager:Init(controllerManager)
    self.controllerManager = controllerManager
    self.onShowEvent = Event:new()
    self.onHideEvent = Event:new()
    self.onBeforeOpenEvent = Event:new()
    self.onBeforeCloseEvent = Event:new()
    WindowManager.OnCreateWindowCallBack = function(functionName)
        self:OnCreateWindow(functionName)
    end
    CS.WindowManager.Instance:OnCreateWindowEvent("+", WindowManager.OnCreateWindowCallBack)

    WindowManager.OnBeforeOpenCallBack = function(functionName)
        self:OnBeforeOpen(functionName)
    end
    CS.WindowManager.Instance:OnBeforeOpenEvent("+", WindowManager.OnBeforeOpenCallBack)

    WindowManager.OnActivedCallBack = function(functionName)
        self:OnActived(functionName)
    end
    CS.WindowManager.Instance:OnActivatedEvent("+", WindowManager.OnActivedCallBack)

    WindowManager.OnAfterOpenCallBack = function(functionName)
        self:OnAfterOpen(functionName)
    end
    CS.WindowManager.Instance:OnAfterOpenEvent("+", WindowManager.OnAfterOpenCallBack)

    WindowManager.OnBeforeCloseCallBack = function(functionName)
        self:OnBeforeClose(functionName)
    end
    CS.WindowManager.Instance:OnBeforeCloseEvent("+", WindowManager.OnBeforeCloseCallBack)

    WindowManager.OnAfterCloseCallBack = function(functionName)
        self:OnAfterClose(functionName)
    end
    CS.WindowManager.Instance:OnAfterCloseEvent("+", WindowManager.OnAfterCloseCallBack)

    WindowManager.OnDestroyEventCallBack = function(functionName)
        self:OnDestroy(functionName)
    end
    CS.WindowManager.Instance:OnDestroyEvent("+", WindowManager.OnDestroyEventCallBack)

    WindowManager.OnShowCallBack = function(functionName)
        self:OnShow(functionName)
    end
    CS.WindowManager.Instance:OnShowEvent("+", WindowManager.OnShowCallBack)

    WindowManager.OnHideCallBack = function(functionName)
        self:OnHide(functionName)
    end
    CS.WindowManager.Instance:OnHideEvent("+", WindowManager.OnHideCallBack)
end

function WindowManager:Dispose()
    CS.WindowManager.Instance:OnCreateWindowEvent("-", WindowManager.OnCreateWindowCallBack)
    CS.WindowManager.Instance:OnBeforeOpenEvent("-", WindowManager.OnBeforeOpenCallBack)
    CS.WindowManager.Instance:OnActivatedEvent("-", WindowManager.OnActivedCallBack)
    CS.WindowManager.Instance:OnAfterOpenEvent("-", WindowManager.OnAfterOpenCallBack)
    CS.WindowManager.Instance:OnBeforeCloseEvent("-", WindowManager.OnBeforeCloseCallBack)
    CS.WindowManager.Instance:OnAfterCloseEvent("-", WindowManager.OnAfterCloseCallBack)
    CS.WindowManager.Instance:OnDestroyEvent("-", WindowManager.OnDestroyEventCallBack)
    CS.WindowManager.Instance:OnShowEvent("-", WindowManager.OnShowCallBack)
    CS.WindowManager.Instance:OnHideEvent("-", WindowManager.OnHideCallBack)
    self.onShowEvent:RemoveAllListeners()
    self.onHideEvent:RemoveAllListeners()
    self.onBeforeCloseEvent:RemoveAllListeners()
    self.onBeforeOpenEvent:RemoveAllListeners()
end

function WindowManager:OnCreateWindow(windowName)
    local key = windowName:sub(1, 1):lower() .. windowName:sub(2)
    local controller = self.controllerManager[key]

    if controller then
        if self.windows[windowName] == nil then
            local classPath = ""
            if (CS.WindowsConfig.Get(windowName).isLua) then
                classPath = "Scripts.UIs." .. windowName .. "." .. windowName
            else
                classPath = "Scripts.UIs.WindowBase"
            end

            local window = Assets.req(classPath).new()

            local csharpWindow = CS.WindowManager.Instance:FindWindow(windowName)
            window.classPath = classPath
            window.functionName = windowName
            window.myController = controller
            controller.window = window
            window:initUI(csharpWindow.gameObject)

            self.windows[windowName] = window
        end
    end

    return self.windows[windowName]
end

function WindowManager:ReleaseWindow(windowName)
end

function WindowManager:OnBeforeOpen(windowName)
    if self.windows[windowName] then
        self.windows[windowName]:OnBeforeOpen()
    end
    self.onBeforeOpenEvent.emitter:Invoke(windowName)
end

function WindowManager:OnActived(windowName)
    if self.windows[windowName] then
        self.windows[windowName]:OnActived()
    end
end

function WindowManager:OnAfterOpen(windowName)
    if self.windows[windowName] then
        self.windows[windowName]:OnAfterOpen()
    end
end

function WindowManager:OnBeforeClose(windowName)
    if self.windows[windowName] then
        self.windows[windowName]:OnBeforeClose()
    end
    self.onBeforeCloseEvent.emitter:Invoke(windowName)
end

function WindowManager:OnAfterClose(windowName)
    self:RemoveWindow(windowName)
end

function WindowManager:OnDestroy(windowName)
    self:RemoveWindow(windowName)
end

function WindowManager:RemoveWindow(windowName)
    if self.windows[windowName] then
        self.windows[windowName]:OnAfterClose()
        self.windows[windowName]:destroy()
        self.windows[windowName] = nil
    end
end

function WindowManager:OnShow(windowName)
    if self.windows[windowName] then
        self.windows[windowName]:OnShow()
    end
    self.onShowEvent.emitter:Invoke(windowName)
end

function WindowManager:OnHide(windowName)
    if self.windows[windowName] then
        self.windows[windowName]:OnHide()
    end
    self.onHideEvent.emitter:Invoke(windowName)
end
