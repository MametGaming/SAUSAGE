local List0 = {
	[1] = {1,"圣诞主题","ShengDan","ShengDan",1},
	[2] = {2,"春节主题","ChunJie","ChunJieJiaoBiao",1},
	[3] = {3,"情人节主题","QingRenJie","QingRenJieJiaoBiao",1},
	[234881024] = {234881024,"全民主题","QuanMin","",1},
	[234881025] = {234881025,"派对主题","PaiDui","",1},
	[234881027] = {234881027,"嘻哈主题","XiHa","",1},
	[1040187392] = {1040187392,"全民主题（海外）","QuanMin","",1},
	[1040187393] = {1040187393,"派对主题（海外）","PaiDui","",1},
	[1040187394] = {1040187394,"嘻哈主题（海外）","XiHa","",1},
}

local Keys = {1,2,3,234881024,234881025,234881027,1040187392,1040187393,1040187394,}

local List1 = { 
	[1] =  {1},
	[2] =  {2},
	[3] =  {3},
	[234881024] =  {234881024},
	[234881025] =  {234881025},
	[234881027] =  {234881027},
	[1040187392] =  {1040187392},
	[1040187393] =  {1040187393},
	[1040187394] =  {1040187394},
}


local CrateTopicTableBase = {

    -- 记录数
	COUNT = 10,

	-- 表
	List0 = List0,

	-- key集合
	Keys = Keys,

	List1 = List1,


    -- 字段索引
	id = 1,
	name = 2,
	sign = 3,
	mark_sign = 4,
	crate_topic_type = 5,

    -- 标识常量
	["ShengDan"] = "ShengDan",
	["ChunJie"] = "ChunJie",
	["QingRenJie"] = "QingRenJie",
	["QuanMin"] = "QuanMin",
	["PaiDui"] = "PaiDui",
	["XiHa"] = "XiHa",
	["QuanMin"] = "QuanMin",
	["PaiDui"] = "PaiDui",
	["XiHa"] = "XiHa",
}

local languageColumns = {2}
local mt = {
    __index = function(self, key)
        if not key then
            return nil
        end
        return CS.Language.GetConfigContent(self[1000 + key])
    end,
    __metatable = "Don't edit metatable."
}
for k, v in pairs(List0) do
    v.__index = v
    for index, column in pairs(languageColumns) do
        v[1000 + column] = v[column]
        v[column] = nil
    end
    v.__metatable = "Don't edit metatable."
    setmetatable(v, mt)
end

return CrateTopicTableBase