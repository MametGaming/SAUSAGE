local ItemData =
    class(
    {
        addGoldNum = 0,
        addMoneyNum = 0,
        addDiamondNum = 0,
        addDiamondCandyNum = 0,
        addBigCrateKeyNum = 0,
        itemInfoList = {}
    },
    Assets.req("Scripts.Datas.Bases.ItemDataBase")
)

function ItemData:getItem(id)
    if self.itemInfoList[id] then
        return self.itemInfoList[id]
    end
    return nil
end

local CrateItemsUtil = Assets.req("Scripts.Utils.CrateItemsUtil")

function ItemData:getItemInfoByProto() -- 获得初始化的装备id
    if not self.getItemInfo then
        return
    end
    local items = self.getItemInfo.Items
    self:GetItemInfoList(items)
    local ids = ConfigTable.ItemTable:getInitIds()
    for i = 1, #ids do
        local item = {
            ItemId = ids[i],
            IsKnowed = 1,
            Num = 1,
            PlayerItemId = 0,
            Deadline = 0
        }
        if self.itemInfoList[item.ItemId] == nil then
            self.itemInfoList[item.ItemId] = item
        end
    end
end

function ItemData:GetItemInfoList(argItems)
    local items = argItems
    for i = 1, #items do
        local itemData = items[i]
        if self.itemInfoList[itemData.ItemId] == nil then
            self.itemInfoList[itemData.ItemId] = itemData
        end
    end
end

function ItemData:singleItemChangeByProto()
    local item = self.singleItemChange.ItemChange
    self:RefreshItem(item)
end

function ItemData:multiItemChangeByProto()
    local items = self.multiItemChange.ItemChanges
    for i = 1, #items do
        self:RefreshItem(items[i])
    end
end

function ItemData:RefreshItem(argItem)
    local itemData = argItem
    local itemId = itemData.ItemId
    local isAdd = true
    if self.itemInfoList[itemId] then
        local data = self.itemInfoList[itemId]
        itemData.Equip = data.Equip
        if data.IsKnowed == 0 then
            itemData.IsKnowed = 0
        else
            itemData.IsKnowed = 1
        end
        self.itemInfoList[itemId] = itemData
        isAdd = false
    end
    local tempSign = ConfigTable.ItemTable:getSign(itemId)
    local wardrobeTypeId = ConfigTable.ItemTable:getItemTypeId(itemId)
    local typeSign = ConfigTable.ItemTypeTable:getSign(wardrobeTypeId)

    if typeSign == ConfigTable.ItemTypeTable.Gold then
        self.addGoldNum = itemData.Num - self.data.playerData.gold
        isAdd = false
    elseif typeSign == ConfigTable.ItemTypeTable.Money then
        self.addMoneyNum = itemData.Num - self.data.playerData.money
        isAdd = false
    elseif typeSign == ConfigTable.ItemTypeTable.Diamond then
        self.addDiamondNum = itemData.Num - self.data.playerData.diamond
        isAdd = false
    elseif typeSign == ConfigTable.ItemTypeTable.Medal then
        self.data.playerData.medal = itemData.Num
        isAdd = false
    elseif tempSign == ConfigTable.ItemTable.DiamondCandy then
        self.addDiamondCandyNum = itemData.Num - self.data.playerData.diamondCandy
        isAdd = false
    elseif tempSign == ConfigTable.ItemTable.RainbowKey then
        self.addBigCrateKeyNum = itemData.Num - self.data.playerData.bigCrateKey
        isAdd = false
    else
        isAdd = true
    end
    if isAdd then
        if self.itemInfoList[itemId] == nil then
            itemData.IsKnowed = 0
            self.itemInfoList[itemId] = itemData
        end
    end
end

function ItemData:upIsKnowed(argPlayerItemId)
    for key, value in pairs(self.itemInfoList) do
        if value.PlayerItemId == argPlayerItemId then
            value.IsKnowed = 1
            return
        end
    end
end


function ItemData:haseNew()
    local Items = self.getItemInfo.Items
    --print("haseNew",table.dump(Items))
    for i = 1, #Items do
        local item = Items[i]
        local wardrobeTypeId = ConfigTable.ItemTable:getItemTypeId(item.ItemId)
        local typeSign = ConfigTable.ItemTypeTable:getSign(wardrobeTypeId)

        if
            typeSign ~= ConfigTable.ItemTypeTable.Money and typeSign ~= ConfigTable.ItemTypeTable.Gold and typeSign ~= ConfigTable.ItemTypeTable.Score and typeSign ~= ConfigTable.ItemTypeTable.Currency and typeSign ~= ConfigTable.ItemTypeTable.DiamondCandy and
                Items[i].IsKnowed == 0
         then
            -- print("===========>>>",typeSign, ConfigTable.ItemTable:getName(item.ItemId))
            return true
        end
    end
end


--判断是不是通行证会员
function ItemData:isTrafficVip(argSeasonID)
    local itemVipID1, itemVipID2 = self:getItemVipID(argSeasonID)
    if self.itemInfoList[itemVipID1] or self.itemInfoList[itemVipID2] then
        return true
    end
    return false
end

--判断是豪华黄金通行证会员
function ItemData:isTrafficVVIP(argSeasonID)
    local itemVipID1, itemVipID2 = self:getItemVipID(argSeasonID)
    if self.itemInfoList[itemVipID2] then
        return true
    end
    return false
end

-- BUJUNZI 得到当前季票类型 1-普通季票 2-黄金季票 3-豪华季票
function ItemData:getTrafficVipType(argSeasonID)
    local itemVipID1, itemVipID2 = self:getItemVipID(argSeasonID)
    if self.itemInfoList[itemVipID1] then
        return 2
    elseif self.itemInfoList[itemVipID2] then
        return 3
    end
    return 1
end

--得到赛季对应的勋章类型
function ItemData:getItemVipID(argSeasonID)
    local itemID = nil
    local seasonTable = nil
    local itemType = nil
    local itemVipID1 = 0
    local itemVipID2 = 0
    local itemTableID = 0 --表里免费ID
    for k, v in pairs(ConfigTable.TrafficPermitTable.List0) do
        itemID = v[ConfigTable.TrafficPermitTable.traffic_permit_item]
        seasonTable = v[ConfigTable.TrafficPermitTable.traffic_permit_season_id]
        itemType = v[ConfigTable.TrafficPermitTable.traffic_permit_type]
        if seasonTable == argSeasonID and itemType == 1 then
            itemTableID = itemID
        elseif seasonTable == argSeasonID and itemType == 2 then
            itemVipID1 = itemID
        elseif seasonTable == argSeasonID and itemType == 3 then
            itemVipID2 = itemID
        end
    end
    return itemVipID1, itemVipID2, itemTableID
end

--判断是否是激活会员但不是豪华会员
function ItemData:isTrafficVipNoVVip(argSeasonID)
    local itemVipID1, itemVipID2 = self:getItemVipID(argSeasonID)
    local isVip = false
    local isVVip = false
    if self.itemInfoList[itemVipID1] then
        isVip = true
    elseif self.itemInfoList[itemVipID2] then
        isVVip = true
    end
    if isVip and not isVVip then
        return true
    end
    return false
end

function ItemData:getItemResSign(argItemID)
    return ConfigTable.ItemTable:getResSignByID(argItemID)
end

--获取转换点券的数量
function ItemData:getCouponsNumber(argItemId)
    local couponsNumber = 0
    local qualtiy = ConfigTable.ItemTable:getQualtiy(argItemId)
    local wardrobeTypeId = ConfigTable.ItemTable:getItemTypeId(argItemId)
    local typeSign = ConfigTable.ItemTypeTable:getSign(wardrobeTypeId)
    qualtiy = qualtiy + 1
    if typeSign == ConfigTable.ItemTypeTable.SuitSet then
        local tempSuitSetID = ConfigTable.SuitSetTable:getItemSuitId(self.myId)
        local tempItemList = ConfigTable.SuitSetContentTable:getSuitSetContent(tempSuitSetID)
        for i = 1, #tempItemList do
            local tempItemQualtiy = ConfigTable.ItemTable:getQualtiy(tempItemList[i]) + 1
            couponsNumber = couponsNumber + ConfigTable.ItemTicketExchangeTable:getExchangeMoney(tempItemQualtiy)
        end
    else
        couponsNumber = ConfigTable.ItemTicketExchangeTable:getExchangeMoney(qualtiy)
    end
    return couponsNumber
end

--是否拥有该物品(是否显示上新)
function ItemData:isHaveItem(argItemID)
    local isBool = false
    if not self.getItemInfo then
        return isBool
    end
    if argItemID == 116 or argItemID == 493 or (argItemID >= 335544419 and argItemID <= 335544423) then --点券不显示上新
        return isBool
    end
    local Items = self.getItemInfo.Items
    isBool = false
    if self.itemInfoList[argItemID] and self.itemInfoList[argItemID].IsKnowed == 0 then
        isBool = true
    end
    return isBool
end
--套装解析上新显示
function ItemData:suitAnalysis(argItemID)
    local isBool = false
    local tempSuitSetID = ConfigTable.SuitSetTable:getItemSuitId(argItemID)
    --获取套装ID
    if tempSuitSetID > 0 then
        local suitIDS = ConfigTable.SuitSetContentTable:getSuitSetContent(tempSuitSetID)
        --得到套装内容
        for i = 1, #suitIDS do
            if self:isHaveItem(suitIDS[i]) then
                isBool = true
            end
        end
    end
    return isBool
end

--判断物品类型是否是宝箱
function ItemData:isCrateBox(argItemList)
    if #argItemList ~= 1 then
        return false
    end
    local isCrate = false
    local itemTypeID = ConfigTable.ItemTable:getItemTypeId(argItemList[1].ItemId)
    local tempBigTypeSign = ConfigTable.ItemTypeTable:getAssembleId(itemTypeID)
    local sysTypeSign = ConfigTable.SysDictTable:getAssembleSign(tempBigTypeSign)
    if sysTypeSign == ConfigTable.SysDictTable.crate then
        isCrate = true
    end
    return isCrate
end

function ItemData:GetUnGetPrizePoolItems(id)
    local items = CrateItemsUtil:GetPrizePoolItems(id)
    local ids = {}
    if items then
        for i = 1, #items do
            if self:getItem(items[i].itemId) == nil then
                table.insert(ids, items[i].itemId)
            end
        end
    end
    return ids
end

return ItemData
