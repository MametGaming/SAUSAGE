
local VIPData = class({}, Assets.req("Scripts.Datas.Bases.VIPDataBase"))

return VIPData
